// File origin: VS1LAB A2


// This script is executed when the browser loads index.html.
// "console.log" writes to the browser's console. 
// The console window must be opened explicitly in the browser.
// Try to find this output in the browser...
console.log("The geoTagging script is going to start...");

/**
 * A function to retrieve the current location and update the page.
 * It is called once the page has been fully loaded.
 */

//Aufagbe 3.2.2
function updateLocation(){

    //get new map from mapQuest with API key
    let newMap = new MapManager("qLcGFWbvMErinkcPHNT3lOnenpAXPru0");
    let myLatitude = document.getElementById("tag_latitude").value;
    let myLongitude = document.getElementById("tag_longitude").value;

    //check if latitude and longitude are already in the fieldset
    if (myLatitude == "" && myLongitude == ""){  

        LocationHelper.findLocation((location) => {

        newLatitude = location.latitude;
        newLongitude =  location.longitude;

        console.log("Getting location: " + newLatitude + ", " + newLongitude);

        //updated the feld in tagging and hidden input in discovery
        document.getElementById("tag_latitude").value = newLatitude;
        document.getElementById("discovery_latitude").value = newLatitude;
        
        document.getElementById("tag_longitude").value = newLongitude;
        document.getElementById("discovery_longitude").value = newLongitude;

        let newMapUrl = newMap.getMapUrl(newLatitude, newLongitude);
        
        document.getElementById("mapView").src = newMapUrl;

        });
   
    } else {
        //Aufgabe 3.2.3
        // Get JSON-String from data-tags attribute and convert it to an array of Geotag objects
        let taglist_json = document.getElementById("mapView").getAttribute("data-tags");
        let tags = JSON.parse(taglist_json);

        let newMapUrl = newMap.getMapUrl(myLatitude, myLongitude, tags, 13);

        document.getElementById("mapView").src = newMapUrl;

    }

}

//Aufgabe 4

//per HTTP POST in JSON Format
function addTag(event){
    //Absenden verhindern
    event.preventDefault();

    const latitude = document.getElementById("tag_latitude").value;
    const longitude = document.getElementById("tag_longitude").value;
    const name = document.getElementById("tag_name").value;
    const hashtag = document.getElementById("tag_hashtag").value;
    
    fetch("http://localhost:3000/api/geotags", {
    method: "POST",
    headers: { 
        "Content-Type": "application/json" 
    },
    body: JSON.stringify({latitude:latitude, longitude:longitude, name:name, hashtag:hashtag})
    })
    .then(response =>response.json())
    .then(data => {
        updateDiscovery(data);
        console.log('Erfolg:', data)})
    .catch(error => console.error('Fehler:', error));

}
// TODO update new map not working..
function updateDiscovery(data) {
    let newMap = new MapManager("qLcGFWbvMErinkcPHNT3lOnenpAXPru0");
    let taglist = document.getElementById("discoveryResults");
    let li = document.createElement("li");
    li.appendChild(document.createTextNode(`${data.name} ( ${data.latitude} ,${data.longitude}) ${data.hashtag}`));
    taglist.appendChild(li);
/* 
    let taglist_json = document.getElementById("mapView").getAttribute("data-tags");
    let tags = JSON.parse(taglist_json);
    let newMapUrl = newMap.getMapUrl(data.latitude, data.longitude, tags, 13);
    document.getElementById("mapView").src = newMapUrl; */

}

//Daten per HTTP GET mit Query Parametern 

function searchTag(event){
    event.preventDefault();
    const search = document.getElementById("searchterm").value;
    const latitude = parseFloat(document.getElementById("discovery_latitude").value);
    const longitude = parseFloat(document.getElementById("discovery_longitude").value);

    fetch(`http://localhost:3000/api/geotags/?` + new URLSearchParams({
        search: search,
        lat: latitude,
        lon: longitude
    }), {
        methode: "GET",
        headers: { "Content-Type": "application/json" },
    })
    .then(response =>response.json())
    .then(data => {
        console.log('Erfolg:', data)})
    .catch(error => console.error('Fehler:', error));
}


// Wait for the page to fully load its DOM content, then call updateLocation
document.addEventListener("DOMContentLoaded",() => {
    updateLocation();
    document.getElementById("tag_form").addEventListener("submit", addTag);
    document.getElementById("discoveryFilterForm").addEventListener("submit", searchTag);
});