// File origin: VS1LAB A2


// This script is executed when the browser loads index.html.
// "console.log" writes to the browser's console. 
// The console window must be opened explicitly in the browser.
// Try to find this output in the browser...
console.log("The geoTagging script is going to start...");


const tagsPerPage = 3;
let tagCount = 0;
let page = 0;


function updatePage() {
    const pageText = document.getElementById("page_text");
    pageText.innerHTML = `S: ${page + 1}/${Math.ceil(tagCount / tagsPerPage)} (${tagCount})`

    const prevPage = document.getElementById("prev_page");
    const nextPage = document.getElementById("next_page");

    if(page === 0) {
        prevPage.disabled = true;
    }else{
        prevPage.disabled = false;
    }

    if(page === Math.ceil(tagCount / tagsPerPage) - 1) {
        nextPage.disabled = true;
    }else{
        nextPage.disabled = false;
    }

    console.log("update");
}

async function previousPage(){
    console.log("prevPage");
    if(page > 0){
        page--;

        const search = document.getElementById("searchterm").value;
        const latitude = parseFloat(document.getElementById("discovery_latitude").value);
        const longitude = parseFloat(document.getElementById("discovery_longitude").value);
    
        let tags = await getFilteredListRequest(latitude, longitude, page  * tagsPerPage, tagsPerPage, search);
    
        updateList(tags);
        updateMap(tags);
    }
}

async function nextPage(){
    console.log("nextPage");
    if(page < Math.ceil(tagCount / tagsPerPage) - 1)
    {
        page++;

        const search = document.getElementById("searchterm").value;
        const latitude = parseFloat(document.getElementById("discovery_latitude").value);
        const longitude = parseFloat(document.getElementById("discovery_longitude").value);
    
        let tags = await getFilteredListRequest(latitude, longitude, page  * tagsPerPage, tagsPerPage, search);
    
        updateList(tags);
        updateMap(tags);
    }
}

/**
 * A function to retrieve the current location and update the page.
 * It is called once the page has been fully loaded.
 */

//Aufagbe 3.2.2
function updateLocation(){

    //get new map from mapQuest with API key
    let newMap = new MapManager("qLcGFWbvMErinkcPHNT3lOnenpAXPru0");
    let myLatitude = document.getElementById("tag_latitude").value;
    let myLongitude = document.getElementById("tag_longitude").value;

    //check if latitude and longitude are already in the fieldset
    if (myLatitude == "" && myLongitude == ""){  

        LocationHelper.findLocation((location) => {

        newLatitude = location.latitude;
        newLongitude =  location.longitude;

        console.log("Getting location: " + newLatitude + ", " + newLongitude);

        //updated the feld in tagging and hidden input in discovery
        document.getElementById("tag_latitude").value = newLatitude;
        document.getElementById("discovery_latitude").value = newLatitude;
        
        document.getElementById("tag_longitude").value = newLongitude;
        document.getElementById("discovery_longitude").value = newLongitude;

        let newMapUrl = newMap.getMapUrl(newLatitude, newLongitude);
        
        document.getElementById("mapView").src = newMapUrl;

        });
   
    } else {
        //Aufgabe 3.2.3
        // Get JSON-String from data-tags attribute and convert it to an array of Geotag objects
        let taglist_json = document.getElementById("mapView").getAttribute("data-tags");
        let tags = JSON.parse(taglist_json);

        let newMapUrl = newMap.getMapUrl(myLatitude, myLongitude, tags, 13);

        document.getElementById("mapView").src = newMapUrl;

    }

}

//Aufgabe 4

//per HTTP POST in JSON Format
async function addTag(event){
    //Absenden verhindern
    event.preventDefault();

    const search = document.getElementById("searchterm").value;
    const latitude = document.getElementById("tag_latitude").value;
    const longitude = document.getElementById("tag_longitude").value;
    const name = document.getElementById("tag_name").value;
    const hashtag = document.getElementById("tag_hashtag").value;
    
    let tag = await addTagRequest(latitude, longitude, name, hashtag);

    if(tag) {
       let tags = await getFilteredListRequest(latitude, longitude, 0, tagsPerPage, search);

        updateList(tags);
        updateMap(tags); 
    }
}

//Daten per HTTP GET mit Query Parametern 

async function searchTag(event){
    event.preventDefault();
    const search = document.getElementById("searchterm").value;
    const latitude = parseFloat(document.getElementById("discovery_latitude").value);
    const longitude = parseFloat(document.getElementById("discovery_longitude").value);

    let tags = await getFilteredListRequest(latitude, longitude, 0, tagsPerPage, search);

    page = 0;
    updateList(tags);
    updateMap(tags);
}

async function addTagRequest(latitude, longitude, name, hashtag) {
    try {
        let response = await fetch("http://localhost:3000/api/geotags", {
        method: "POST",
        headers: { 
            "Content-Type": "application/json" 
        },
        body: JSON.stringify({latitude:latitude, longitude:longitude, name:name, hashtag:hashtag})
        });

        let tag = await response.json();

        console.log('Erfolg:', tag);

        return tag;
    } catch (error) {
        console.error('Fehler:', error);
        
        return null;
    }
}

async function getFilteredListRequest(lat, lon, fromIndex, count, searchterm = "") {

try {
    let response = await fetch(`http://localhost:3000/api/geotags/pages/?` + new URLSearchParams({
        search: searchterm,
        lat: lat,
        lon: lon,
        fromIndex: fromIndex,
        count: count
    }), {
        methode: "GET",
        headers: { "Content-Type": "application/json" },
    });

    let {total, list} = await response.json();

    tagCount = total;

    console.log('Erfolg:', list);

    return list;
} catch (error) {
    console.error('Fehler:', error);
    return [];
}


}

function updateList(tags) {

    let list = document.getElementById("discoveryResults");
    list.innerHTML = "";

    for (const tag of tags){
        let tagNode = document.createElement("li");
        tagNode.appendChild(document.createTextNode(`${tag.name} ( ${tag.latitude} ,${tag.longitude}) ${tag.hashtag}`));
        list.appendChild(tagNode);
    }

    console.log("Update List:")
    console.log(tags)

    updatePage();
}

function updateMap(tags) {

    let newMap = new MapManager("qLcGFWbvMErinkcPHNT3lOnenpAXPru0");
    let myLatitude = document.getElementById("tag_latitude").value;
    let myLongitude = document.getElementById("tag_longitude").value;

    let newMapUrl = newMap.getMapUrl(myLatitude, myLongitude, tags, 13);

    document.getElementById("mapView").src = newMapUrl;

}

// Wait for the page to fully load its DOM content, then call updateLocation
document.addEventListener("DOMContentLoaded",async ()  => {
    updateLocation();
    document.getElementById("tag_form").addEventListener("submit", addTag);
    document.getElementById("discoveryFilterForm").addEventListener("submit", searchTag);
    document.getElementById("searchterm").value = "";

    document.getElementById("prev_page").addEventListener("click", previousPage);
    document.getElementById("next_page").addEventListener("click", nextPage);

    const latitude = parseFloat(document.getElementById("discovery_latitude").value);
    const longitude = parseFloat(document.getElementById("discovery_longitude").value);
    
    let tags = await getFilteredListRequest(latitude, longitude, 0, tagsPerPage, "");

    updateList(tags);
    updateMap(tags);
});